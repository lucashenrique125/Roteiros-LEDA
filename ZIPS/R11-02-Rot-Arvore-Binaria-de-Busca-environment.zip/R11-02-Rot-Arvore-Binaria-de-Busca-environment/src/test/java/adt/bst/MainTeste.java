package adt.bst;

import java.util.Arrays;

public class MainTeste {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		BSTImpl bst = new BSTImpl<>();
		
		
		

		
		System.out.println(bst.size());
	}
}
